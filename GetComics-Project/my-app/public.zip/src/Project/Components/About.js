import React from "react";
import Aboutcontent from "./About/about";
import Navbar from "./Navbar";

function About(){
    
    return(
        <div>
            <Navbar />

            <Aboutcontent />
        </div>
    )
}

export default About;