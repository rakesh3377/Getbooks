import React from 'react';
//import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import { additem } from '../redux/reducer/cart';
import '../styles/product.css';
import { FaRegHeart } from "react-icons/fa";


const Product = ({ product }) => {
    const dispatch = useDispatch();
    const list = useSelector((state) => state.cart.list);
    const element = list.find((item) => item.id === product.id);

    const addtocart = () => {
        dispatch(additem({ ...product, count: 0 }));


    };
    return (
        <div className='cards-container'>
            <div className="products-div">
                <div className='img'>
                    <img src={product.img} alt={product.title} />
                </div>
                <div className="details">
                    <h3>{product.title}</h3>
                </div>
                <div className='buttons'>
                    <div className='anchor'>
                        <a href={product.file} download>download
                        </a>
                    </div>
                    <div>
                        <button className='btn-1' onClick={addtocart}><FaRegHeart /></button>
                    </div>
                </div>

            </div>
        </div>

    );
};

export default Product;
