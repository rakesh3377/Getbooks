export const Sliderimage = [
    {
        image: "/images/batman.jpg",
        title: "Batman-Brave and the Bold",
    },
    {
        image: "/images/dc-group.jpeg",
        title: "Justice Leage",
    },
    {
        image: "/images/flashpoint.jpeg",
        title: "flash point-paradox",
    },
    {
        image: "/images/invencible.jpg",
        title: "Invecible",
    },
    {
        image: "/images/marvel.jpeg",
        title: "Avengers vs X-men",
    },
];