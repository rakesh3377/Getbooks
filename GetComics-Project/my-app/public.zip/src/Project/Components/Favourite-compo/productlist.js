import React from 'react'
import '../styles/favor.css'


export default function Productlist(product) {
    return (
        <div>

            <div className="productlist">
                <div className='favor-img'>
                    <img src={product.img} alt={product.title} />
                </div>
                <div className="favor-title">
                    <h3>{product.title}</h3>
                </div>
                <div>
                    <button onClick={product.removeitem}>remove</button>
                </div>

            </div>
        </div>

    )
}
