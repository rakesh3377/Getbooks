import React, { useState } from "react";
import Slider from "./Home-components/Slider";
import { Sliderimage } from "./Home-components/Slider-data";
import '../Components/styles/Home.css'
import data from '../Components/asset/products.json';
import Product from "./Home-components/product";
import Navbar from "./Navbar";

function Home() {
    const [products] = useState(data);
    
    return (
        <div className="Container">
            <Navbar />
            <div>
                <Slider images={Sliderimage} />
            </div>
            <div className="product">
                {products.map((product) => (
                    <Product key={product.id} product={product} />
                ))}
            </div>
        </div>
    )
}

export default Home;