import React from "react";
import Navbar from "./Navbar";


function Events(){
    return(
        <di>
            <Navbar />
            <h1>New Updates</h1>
        </di>
    )
}

export default Events;